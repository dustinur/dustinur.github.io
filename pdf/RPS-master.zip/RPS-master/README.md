# RPS
Rock, paper, scissors (javascript &amp; jquery practice)
